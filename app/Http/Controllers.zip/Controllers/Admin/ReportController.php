<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\AppModules;
use App\Models\CustomerLeadProfile;
use App\Models\CustomerLeadComplaints;
use App\Models\CustomerLeadOrders;
use App\Models\CustomerOrders;
use App\Models\CustomersCollections;
use App\Models\RoleModule;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

use function Psy\debug;

class ReportController extends Controller
{
   // initial constructor
   public function __construct()
   {
       $route_name = Route::currentRouteName();
       $this->middleware('permissioncheck:'.$route_name);

       $routeParse = explode('_',$route_name);
       if($route_name == 'home'){
           $routeName = 'home';
       }else{
           $routeName = 'manage_'.$routeParse[1];
       }

       $this->module_info = AppModules::get_module_id_by_slug($routeName);
   }

    //getter function to module id from constructor
    public function getModuleId()
    {
        return $this->module_info->id;
    }


    public function show_reports()
    
    {
       
        $modules = RoleModule::get_active_modules_by_role_id();
        return view('manage-reports.showreports',[
            'app_modules' => $modules,
        ]);
    }

    public function lead_reports(Request $request)
    {
        // dd($request);
       $all_leads = CustomerLeadProfile::where('isLead',1)->where('isActive',1);
       
       $from_filter_date = $request->from_date;
       $to_filter_date = $request->to_date;
       $employee_assigned_filter_id = $request->assigned_to;
       if($from_filter_date && $to_filter_date){ 
           $all_leads->whereBetween('created',[$from_filter_date." 00:00:00",$to_filter_date." 23:59:59"]); 
       }
       if($employee_assigned_filter_id){
           $all_leads->where('customer_assigned_to',$employee_assigned_filter_id);
       }

       $all_leads = $all_leads->paginate(10);

       if(Auth::user()->id == 1){
           $my_employees = User::where('isActive',1)->get();
       }else{
           $my_employees = User::where('added_by',Auth::user()->id)->where('isActive',1)->get();
       }
        $modules = RoleModule::get_active_modules_by_role_id();
        return view('manage-reports.leadreports',[
            'app_modules' => $modules,
             'all_leads' => $all_leads,
             'my_employees' => $my_employees,
        ]);
    }

    public function complaint_reports(Request $request)
    {
        // dd($request);
       $all_complaints = CustomerLeadComplaints::where('id','>=',1);
       
       $from_filter_date = $request->from_date;
       $to_filter_date = $request->to_date;
       $employee_assigned_filter_id = $request->complaint_received_by;
       if($from_filter_date && $to_filter_date){ 
           $all_complaints->whereBetween('created', [$from_filter_date." 00:00:00",$to_filter_date." 23:59:59"]); 
            // dd($from_filter_date." 00:00:00",$to_filter_date." 23:59:59");
       }
       if($employee_assigned_filter_id){
           $all_complaints->where('complaint_received_by',$employee_assigned_filter_id);
       }

      $all_complaints = $all_complaints->paginate(10);
        

       if(Auth::user()->id == 1){
           $my_employees = User::where('isActive',1)->get();
       }else{
           $my_employees = User::where('added_by',Auth::user()->id)->where('isActive',1)->get();
       }
        $modules = RoleModule::get_active_modules_by_role_id();
        return view('manage-reports.complaintreports',[
            'app_modules' => $modules,
             'all_complaints' => $all_complaints,
             'my_employees' => $my_employees,
             
        ]);
    }

    public function collection_reports(Request $request)
    {
        // dd($request);
       $all_collections = CustomersCollections::where('id','>=',1);
       
       $from_filter_date = $request->from_date;
       $to_filter_date = $request->to_date;
       $employee_assigned_filter_id = $request->assigned_to;
       if($from_filter_date && $to_filter_date){ 
           $all_collections->whereBetween('created', [$from_filter_date." 00:00:00",$to_filter_date." 23:59:59"]); 
       }

       if($employee_assigned_filter_id){
           $all_collections->where('collected_by_person_name',$employee_assigned_filter_id);
       }

        $all_collections = $all_collections->paginate(10);

       if(Auth::user()->id == 1){
           $my_employees = User::where('isActive',1)->get();
       }else{
           $my_employees = User::where('added_by',Auth::user()->id)->where('isActive',1)->get();
       }
        $modules = RoleModule::get_active_modules_by_role_id();
        return view('manage-reports.collectionreports',[
            'app_modules' => $modules,
             'all_collections' => $all_collections,
             'my_employees' => $my_employees,
             
        ]);
    }

    public function order_reports(Request $request)
    {
        // dd($request);
       $all_orders = CustomerOrders::where('id','>=',1);
       
       $from_filter_date = $request->from_date;
       $to_filter_date = $request->to_date;
       $employee_assigned_filter_id = $request->assigned_to;
       if($from_filter_date && $to_filter_date){ 
           $all_orders->whereBetween('created', [$from_filter_date." 00:00:00",$to_filter_date." 23:59:59"]); 
       }
       if($employee_assigned_filter_id){
           $all_orders->where('order_made_by',$employee_assigned_filter_id);
       }

        $all_orders = $all_orders->paginate(10);

       if(Auth::user()->id == 1){
           $my_employees = User::where('isActive',1)->get();
       }else{
           $my_employees = User::where('added_by',Auth::user()->id)->where('isActive',1)->get();
       }
        $modules = RoleModule::get_active_modules_by_role_id();
        return view('manage-reports.orderreports',[
            'app_modules' => $modules,
             'all_orders' => $all_orders,
             'my_employees' => $my_employees,
             
        ]);
    }
}
